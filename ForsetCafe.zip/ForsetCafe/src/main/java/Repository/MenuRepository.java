package Repository;

public interface MenuRepository {

}
