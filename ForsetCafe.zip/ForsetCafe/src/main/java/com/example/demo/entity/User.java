package com.example.demo.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;


@Entity
@Table(name="User_Table")
public class User {

	@Id
    @Column(name="Firstname")
    private String firstname;
    @Column(name="PhoneNumber")
    private String phoneNumber;
    @Column(name="email")
    private String email;
    @Column(name="password")
    private String password;
    @Column(name="location")
    private String location;
    @Column(name="role")
    private String role;
	public String getFirstname() {
		return firstname;
	}
	public void setFirstname(String firstname) {
		this.firstname = firstname;
	}
	public String getPhoneNumber() {
		return phoneNumber;
	}
	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getLocation() {
		return location;
	}
	public void setLocation(String location) {
		this.location = location;
	}
	public String getRole() {
		return role;
	}
	public void setRole(String role) {
		this.role = role;
	}
	@Override
	public String toString() {
		return "User [firstname=" + firstname + ", phoneNumber=" + phoneNumber + ", email=" + email + ", password="
				+ password + ", location=" + location + ", role=" + role + "]";
	}
	public User(String firstname, String phoneNumber, String email, String password, String location, String role) {
		super();
		this.firstname = firstname;
		this.phoneNumber = phoneNumber;
		this.email = email;
		this.password = password;
		this.location = location;
		this.role = role;
	}

    public User() {
    	
    }
    

}
