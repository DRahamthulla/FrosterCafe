package com.example.demo.entity;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;


@Entity
@Table(name="Menu")
public class Menu {
	
	@Id
	private String menuName;
	private  String  menuDescription;
	private Float MenuPrice;
	@OneToMany(targetEntity = Category.class,cascade = CascadeType.ALL)
	@JoinColumn(name="category_Id",referencedColumnName = "menuName")
	private List<Category> category;
	public String getMenuName() {
		return menuName;
	}
	public void setMenuName(String menuName) {
		this.menuName = menuName;
	}
	public String getMenuDescription() {
		return menuDescription;
	}
	public void setMenuDescription(String menuDescription) {
		this.menuDescription = menuDescription;
	}
	public Float getMenuPrice() {
		return MenuPrice;
	}
	public void setMenuPrice(Float menuPrice) {
		MenuPrice = menuPrice;
	}
	public List<Category> getCategory() {
		return category;
	}
	public void setCategory(List<Category> category) {
		this.category = category;
	}
	@Override
	public String toString() {
		return "Menu [menuName=" + menuName + ", menuDescription=" + menuDescription + ", MenuPrice=" + MenuPrice
				+ ", category=" + category + "]";
	}
	public Menu(String menuName, String menuDescription, Float menuPrice, List<Category> category) {
		super();
		this.menuName = menuName;
		this.menuDescription = menuDescription;
		MenuPrice = menuPrice;
		this.category = category;
	}

	
	public Menu() {
		
	}
	
	
	
	
	
	}
	
	
	

	