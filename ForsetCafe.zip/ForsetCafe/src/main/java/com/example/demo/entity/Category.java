package com.example.demo.entity;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table( name="Category")
public class Category {
	
	@Id
	private int categoryId;
	private String breakfast;
	private String lunch;
	private String Dinner;
	
	@ManyToOne(cascade = CascadeType.ALL)
	@JoinColumn(name="menuName")
	private Menu menu;
	
	
	
	

	public int getCategoryId() {
		return categoryId;
	}





	public void setCategoryId(int categoryId) {
		this.categoryId = categoryId;
	}





	public String getBreakfast() {
		return breakfast;
	}





	public void setBreakfast(String breakfast) {
		this.breakfast = breakfast;
	}





	public String getLunch() {
		return lunch;
	}





	public void setLunch(String lunch) {
		this.lunch = lunch;
	}





	public String getDinner() {
		return Dinner;
	}





	public void setDinner(String dinner) {
		Dinner = dinner;
	}





	public Menu getMenu() {
		return menu;
	}





	public void setMenu(Menu menu) {
		this.menu = menu;
	}





	@Override
	public String toString() {
		return "Category [categoryId=" + categoryId + ", breakfast=" + breakfast + ", lunch=" + lunch + ", Dinner="
				+ Dinner + ", menu=" + menu + "]";
	}





	public Category(int categoryId, String breakfast, String lunch, String dinner, Menu menu) {
		super();
		this.categoryId = categoryId;
		this.breakfast = breakfast;
		this.lunch = lunch;
		Dinner = dinner;
		this.menu = menu;
	}





	public Category() {
		
	}
	
}
