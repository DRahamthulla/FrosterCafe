package com.example.demo.entity;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="Reservation")
public class Reservation {
	
	
	
	private String name;
	@Id
	private String email;
	private long phone;
	private String Date;
	private int Time;
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public long getPhone() {
		return phone;
	}
	public void setPhone(long phone) {
		this.phone = phone;
	}
	public String getDate() {
		return Date;
	}
	public void setDate(String date) {
		Date = date;
	}
	public int getTime() {
		return Time;
	}
	public void setTime(int time) {
		Time = time;
	}
	public Reservation(String name, String email, long phone, String date, int time) {
		super();
		this.name = name;
		this.email = email;
		this.phone = phone;
		Date = date;
		Time = time;
	}
	@Override
	public String toString() {
		return "Reservation [name=" + name + ", email=" + email + ", phone=" + phone + ", Date=" + Date + ", Time="
				+ Time + "]";
	}
	
	public Reservation() {
		
	}
	
	   

	
	

}
